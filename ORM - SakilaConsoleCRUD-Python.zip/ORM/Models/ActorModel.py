
from sqlalchemy.orm import relationship
from sqlalchemy import Column, String,Table,ForeignKey
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base
from .AssciationTables import film_actor

class ActorModel(Base):
    __tablename__ = "actor"
    actor_id    = Column(Integer, primary_key=True)
    first_name  = Column(String(45), nullable=False)
    last_name   = Column(String(45), nullable=False)
    last_update = Column(DateTime, nullable=False)

    films = relationship("FilmModel", secondary=film_actor, back_populates="actors")

    def __repr__(self):
        return f"<Actor(id={self.actor_id}, name='{self.first_name} {self.last_name}')>"