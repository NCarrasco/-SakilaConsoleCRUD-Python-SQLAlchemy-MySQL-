from sqlalchemy.orm import relationship
from sqlalchemy import Column, String,Table,ForeignKey
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base
from .AssciationTables import film_category

class CategoryModel(Base):
    __tablename__ = "category"
    category_id  = Column(Integer, primary_key=True)
    name         = Column(String(25), nullable=False)
    last_update  = Column(DateTime, nullable=False)

    films = relationship("FilmModel", secondary=film_category, back_populates="categories")

    def __repr__(self):
        return f"<Category(id={self.category_id}, name='{self.name}')>"
