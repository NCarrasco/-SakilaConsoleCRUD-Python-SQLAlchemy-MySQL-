from sqlalchemy import (
    Column,Integer, DateTime,
    Float, SmallInteger,Text,String, ForeignKey
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql.sqltypes import Integer, SmallInteger, Float, DateTime
from .Base import Base        
from .AssciationTables import film_actor, film_category

class FilmModel(Base):
    __tablename__ = "film"
    film_id              = Column(Integer, primary_key=True)
    title                = Column(String(255), nullable=False)
    description          = Column(Text)
    release_year         = Column(Integer)
    language_id          = Column(Integer, ForeignKey("language.language_id"),  nullable=False)
    original_language_id = Column(Integer, ForeignKey("language.language_id"))
    rental_duration      = Column(SmallInteger, nullable=False)
    rental_rate          = Column(Float, nullable=False)
    length               = Column(SmallInteger)
    replacement_cost     = Column(Float, nullable=False)
    rating               = Column(String(10))
    special_features     = Column(String(255))
    last_update          = Column(DateTime, nullable=False)

    language    = relationship("LanguageModel", back_populates="films",
                               foreign_keys=[language_id])
    actors      = relationship("ActorModel",    secondary=film_actor,
                               back_populates="films")
    categories  = relationship("CategoryModel", secondary=film_category,
                               back_populates="films")
    inventories = relationship("InventoryModel", back_populates="film")

    def __repr__(self):
        return f"<Film(id={self.film_id}, title='{self.title}')>"