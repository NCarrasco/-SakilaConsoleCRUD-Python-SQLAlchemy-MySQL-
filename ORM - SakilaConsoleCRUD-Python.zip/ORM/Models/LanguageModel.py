
from sqlalchemy.orm import relationship
from sqlalchemy import Column, String
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base

class LanguageModel(Base):
    __tablename__ = "language"
    language_id  = Column(Integer, primary_key=True)
    name         = Column(String(20), nullable=False)
    last_update  = Column(DateTime, nullable=False)

    films = relationship(
        "FilmModel",
        back_populates="language",
        foreign_keys="FilmModel.language_id"          # ← ruta NO ambigua
    )

    def __repr__(self):
        return f"<Language(id={self.language_id}, name='{self.name}')>"