from sqlalchemy import (
    Column,Integer, DateTime,ForeignKey
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base

class StoreModel(Base):
    __tablename__ = "store"
    store_id          = Column(Integer, primary_key=True)
    manager_staff_id  = Column(Integer, ForeignKey("staff.staff_id"), nullable=False)
    address_id        = Column(Integer, ForeignKey("address.address_id"), nullable=False)
    last_update       = Column(DateTime, nullable=False)

    # ‼ explícita la FK que relaciona muchos-a-uno con Staff.store_id
    staff        = relationship(
        "StaffModel",
        back_populates="store",
        foreign_keys="StaffModel.store_id"
    )
    # relación uno-a-uno para el manager
    manager_staff = relationship(
        "StaffModel",
        foreign_keys=[manager_staff_id]
    )

    address     = relationship("AddressModel", back_populates="stores")
    inventories = relationship("InventoryModel", back_populates="store")
    customers   = relationship("CustomerModel",  back_populates="store")

    def __repr__(self):
        return f"<Store(id={self.store_id})>"