
from sqlalchemy import (
    Column,Integer, DateTime,Boolean,
    String, ForeignKey
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base

class CustomerModel(Base):
    __tablename__ = "customer"
    customer_id  = Column(Integer, primary_key=True)
    store_id     = Column(Integer, ForeignKey("store.store_id"),  nullable=False)
    first_name   = Column(String(45), nullable=False)
    last_name    = Column(String(45), nullable=False)
    email        = Column(String(50))
    address_id   = Column(Integer, ForeignKey("address.address_id"), nullable=False)
    activebool   = Column(Boolean, nullable=False)
    create_date  = Column(DateTime, nullable=False)
    last_update  = Column(DateTime)
    active       = Column(Integer)

    address   = relationship("AddressModel", back_populates="customers")
    store     = relationship("StoreModel",   back_populates="customers")
    rentals   = relationship("RentalModel",  back_populates="customer")
    payments  = relationship("PaymentModel", back_populates="customer")

    def __repr__(self):
        return f"<Customer(id={self.customer_id}, name='{self.first_name} {self.last_name}')>"