from sqlalchemy import Table, Column, Integer, ForeignKey, DateTime
from Models.Base import Base

film_actor = Table(
          "film_actor", Base.metadata,
          Column("actor_id", Integer, ForeignKey("actor.actor_id"), primary_key=True),
          Column("film_id",  Integer, ForeignKey("film.film_id"),  primary_key=True),
          Column("last_update", DateTime, nullable=False))

film_category = Table(
          "film_category", Base.metadata,
          Column("film_id",     Integer, ForeignKey("film.film_id"),     primary_key=True),
          Column("category_id", Integer, ForeignKey("category.category_id"), primary_key=True),
          Column("last_update", DateTime, nullable=False))  