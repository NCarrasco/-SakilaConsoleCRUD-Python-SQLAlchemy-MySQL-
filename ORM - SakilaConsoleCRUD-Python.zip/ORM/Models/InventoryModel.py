from sqlalchemy import (
    Column,Integer, DateTime,ForeignKey
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base

class InventoryModel(Base):
    __tablename__ = "inventory"
    inventory_id = Column(Integer, primary_key=True)
    film_id      = Column(Integer, ForeignKey("film.film_id"),  nullable=False)
    store_id     = Column(Integer, ForeignKey("store.store_id"), nullable=False)
    last_update  = Column(DateTime, nullable=False)

    film     = relationship("FilmModel", back_populates="inventories")
    store    = relationship("StoreModel",back_populates="inventories")
    rentals  = relationship("RentalModel",back_populates="inventory")

    def __repr__(self):
        return f"<Inventory(id={self.inventory_id})>"