from sqlalchemy import (
    Column,Integer, DateTime,ForeignKey
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql.sqltypes import Integer,Float, DateTime
from .Base import Base

class PaymentModel(Base):
    __tablename__ = "payment"
    payment_id   = Column(Integer, primary_key=True)
    customer_id  = Column(Integer, ForeignKey("customer.customer_id"), nullable=False)
    staff_id     = Column(Integer, ForeignKey("staff.staff_id"),     nullable=False)
    rental_id    = Column(Integer, ForeignKey("rental.rental_id"),   nullable=False)
    amount       = Column(Float, nullable=False)
    payment_date = Column(DateTime, nullable=False)

    customer = relationship("CustomerModel", back_populates="payments")
    staff    = relationship("StaffModel",    back_populates="payments")
    rental   = relationship("RentalModel")

    def __repr__(self):
        return f"<Payment(id={self.payment_id}, amount={self.amount})>"