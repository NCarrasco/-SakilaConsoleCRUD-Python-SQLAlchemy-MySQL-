from sqlalchemy.orm import relationship
from sqlalchemy import Column, String
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base

class AddressModel(Base):
    __tablename__ = "address"
    address_id   = Column(Integer, primary_key=True)
    address      = Column(String(50), nullable=False)
    address2     = Column(String(50))
    district     = Column(String(20), nullable=False)
    city_id      = Column(Integer)
    postal_code  = Column(String(10))
    phone        = Column(String(20), nullable=False)
    last_update  = Column(DateTime, nullable=False)

    stores        = relationship("StoreModel", back_populates="address")
    staff_members = relationship("StaffModel", back_populates="address")
    customers     = relationship("CustomerModel", back_populates="address")

    def __repr__(self):
        return f"<Address(id={self.address_id}, country='{self.address}')>"