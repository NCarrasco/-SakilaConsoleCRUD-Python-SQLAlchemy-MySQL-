from sqlalchemy import (
    Column,Integer, DateTime,Boolean,
    String, ForeignKey
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base

class StaffModel(Base):
    __tablename__ = "staff"
    staff_id    = Column(Integer, primary_key=True)
    first_name  = Column(String(45), nullable=False)
    last_name   = Column(String(45), nullable=False)
    address_id  = Column(Integer, ForeignKey("address.address_id"), nullable=False)
    email       = Column(String(50))
    store_id    = Column(Integer, ForeignKey("store.store_id"))  # ← la FK “normal”
    active      = Column(Boolean, nullable=False)
    username    = Column(String(16), nullable=False)
    password    = Column(String(40))
    last_update = Column(DateTime, nullable=False)

    # relaciones
    address = relationship("AddressModel", back_populates="staff_members")
    store   = relationship("StoreModel",  back_populates="staff",
                           foreign_keys=[store_id])
    rentals = relationship("RentalModel", back_populates="staff")
    payments= relationship("PaymentModel", back_populates="staff")

    def __repr__(self):
        return f"<Staff(id={self.staff_id}, name='{self.first_name} {self.last_name}')>"