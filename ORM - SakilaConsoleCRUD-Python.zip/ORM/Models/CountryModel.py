from sqlalchemy import Column, String
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base

class CountryModel(Base):
    __tablename__ = "country"
    country_id  = Column(Integer, primary_key=True)
    country     = Column(String(50), nullable=False)
    last_update = Column(DateTime, nullable=False)

    def __repr__(self):
        return f"<Country(id={self.country_id}, country='{self.country}')>"