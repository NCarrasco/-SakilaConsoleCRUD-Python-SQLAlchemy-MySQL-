from sqlalchemy import (
    Column,Integer, DateTime,ForeignKey
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql.sqltypes import Integer, DateTime
from .Base import Base

class RentalModel(Base):
    __tablename__ = "rental"
    rental_id    = Column(Integer, primary_key=True)
    rental_date  = Column(DateTime, nullable=False)
    inventory_id = Column(Integer, ForeignKey("inventory.inventory_id"), nullable=False)
    customer_id  = Column(Integer, ForeignKey("customer.customer_id"),  nullable=False)
    return_date  = Column(DateTime)
    staff_id     = Column(Integer, ForeignKey("staff.staff_id"), nullable=False)
    last_update  = Column(DateTime, nullable=False)

    inventory = relationship("InventoryModel", back_populates="rentals")
    customer  = relationship("CustomerModel",  back_populates="rentals")
    staff     = relationship("StaffModel",     back_populates="rentals")

    def __repr__(self):
        return f"<Rental(id={self.rental_id}, date={self.rental_date})>"