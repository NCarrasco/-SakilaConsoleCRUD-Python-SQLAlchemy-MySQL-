
from Models import *
from DbContext import DbContext
from Models.Base import Base

model_map = {c.__tablename__: c for c in Base.__subclasses__()} 
db = DbContext()

def mostrar_opcion_seleccionada(texto):
    print("\n\033[94m" + "="*50)
    print(f"     HAS SELECCIONADO: {texto.upper()}")
    print("="*50 + "\033[0m\n")

class Program:
    @staticmethod
    def crud_menu(model_class):
        while True:
            print(f"\033[96m\n Seleccione Opción para el mantenimiento de: '{model_class.__tablename__}'")
            print("\033[0m")
            print("1. Crear")
            print("2. Leer por ID")
            print("3. Actualizar")
            print("4. Eliminar")
            print("5. \033[91mVolver\033[0m")

            while True:
                op = input("> ").strip()
                if not op:
                    print("\033[91mEntrada vacía. Debe seleccionar una opción.\033[0m")
                    continue
                if op not in ["1", "2", "3", "4", "5"]:
                    print("\033[91mOpción inválida. Intente nuevamente.\033[0m")
                    continue
                break

            if op == "1":
                mostrar_opcion_seleccionada("Crear")
                db.create_entity_interactive(model_class)
            elif op == "2":
                mostrar_opcion_seleccionada("Leer por ID")
                while True:
                    id_input = input("Ingrese el ID: ").strip()
                    if not id_input.isdigit():
                        print("\033[91mID inválido. Debe ser un número.\033[0m")
                        continuar = input("¿Desea intentarlo nuevamente? (Y/N): ").strip().upper()
                        if continuar != "Y":
                            break
                        continue
                    id = int(id_input)
                    if not db.read_entity(model_class, id):  # Esta función debe devolver True o False
                        print("\033[91mID no encontrado. ¿Desea intentarlo nuevamente? (Y/N): \033[0m")
                        continuar = input("> ").strip().upper()
                        if continuar != "Y":
                            break
                    else:
                        break
            elif op == "3":
                mostrar_opcion_seleccionada("Actualizar")
                db.update_entity_interactive(model_class)
            elif op == "4":
                mostrar_opcion_seleccionada("Eliminar")
                # lógica...
            elif op == "5":
                mostrar_opcion_seleccionada("Volver")
                break

def main():
    grupos = {
        "Catálogo Básico": ["actor", "film", "category", "language"],
        "Transaccionales": ["inventory", "rental", "payment"],
        "Entidades": ["customer", "staff", "store", "address", "country"]
    }

    opciones_ordenadas = []
    for grupo in grupos.values():
        for tabla in grupo:
            if tabla in model_map:
                opciones_ordenadas.append(tabla)

    indice_opciones = {str(i + 1): opciones_ordenadas[i] for i in range(len(opciones_ordenadas))}
    opcion_salida = str(len(opciones_ordenadas) + 1)

    while True:
        print("\033[96m\n======= MENÚ PRINCIPAL - GESTIÓN ORM SAKILA =======\033[0m")
        contador = 1

        for titulo, tablas in grupos.items():
            print(f"\033[94m\n--- {titulo} ---\033[0m")
            for tabla in tablas:
                if tabla in model_map:
                    print(f"\033[92m{contador}. {tabla.capitalize()}\033[0m")
                    contador += 1

        print(f"\n\033[92m{contador}. Salir\033[0m")
        print("\033[93m\nSeleccione una opción para continuar...\033[0m")

        while True:
            entrada = input("> ").strip()

            if not entrada:
                print("\033[91mEntrada vacía. Debe seleccionar una opción.\033[0m")
                continue
            if not entrada.isdigit():
                print("\033[91mEntrada inválida. Use solo números.\033[0m")
                continue
            if entrada == opcion_salida:
                print("\033[95mGracias por usar el sistema. ¡Hasta pronto!\033[0m")
                return
            if entrada in indice_opciones:
                tabla = indice_opciones[entrada]
                Program.crud_menu(model_map[tabla])
                break
            else:
                print(f"\033[91mOpción fuera de rango. Debe elegir entre 1 y {opcion_salida}.\033[0m")

    db.session.close()

if __name__ == "__main__":
    main()
    db.session.close()
