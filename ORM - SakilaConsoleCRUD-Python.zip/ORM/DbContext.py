from sqlalchemy import (
    Column,Integer, DateTime,
    Boolean, Float, SmallInteger, create_engine
)
from sympy import trunc
from tabulate import tabulate
from sqlalchemy.orm import sessionmaker
from sqlalchemy import inspect
from sqlalchemy.sql.sqltypes import Integer, SmallInteger, Float, Boolean, DateTime
from datetime import datetime

class DbContext:
    def __init__(self):
        self.engine = create_engine("mysql+pymysql://root:Admin.123@127.0.0.1/sakila", echo=False)
        self.Session = sessionmaker(bind=self.engine)
        self.session = self.Session()
    
    def create_entity(self,entity):
        self.session.add(entity)
        self.session.commit()
        print(" Creado con éxito.")

    def read_entity(self,cls, pk):
        obj = self.session.get(cls, pk)
        if obj:
            print(obj)
            return True
        else:
            print("\033[93mNo se encontró ningún registro con ese ID.\033[0m")
            return False

    def update_entity(self):
        self.session.commit() 
        print(" Actualizado.")

    def delete_entity(self,cls, pk):
        obj = self.session.get(cls, pk)
        if obj:
           self.session.delete(obj)
           self.session.commit()
           print(" Eliminado.")
        else:
           print(" No encontrado.")
    
    @staticmethod 
    def cast_value(col, raw):
        """Convierte la cadena leída por consola al tipo correcto."""
        if raw == "" and col.nullable:
          return None
        try:
           if isinstance(col.type, (Integer, SmallInteger)):
              return int(raw)
           if isinstance(col.type, Float):
              return float(raw)
           if isinstance(col.type, Boolean):
              return raw.lower() in ("1", "true", "t", "yes", "y", "si")
           if isinstance(col.type, DateTime):
              # Formato rápido: 'YYYY-mm-dd HH:MM:SS'
              return datetime.fromisoformat(raw)
        except Exception:
           pass
        return raw  # string por defecto
    
    def create_entity_interactive(self,cls):
        mapper = inspect(cls)
        data = {}
        for col in mapper.columns:
            # omitir PK autoincrementales
            if col.primary_key and col.autoincrement:
               continue
            prompt = f"{col.name} ({col.type}) [{'NULL' if col.nullable else 'req'}]: "
            val = input(prompt)
            if val == "" and not col.nullable:
               print("⚠ Campo requerido. Abortando creación.")
               return
            data[col.name] = DbContext.cast_value(col, val)
        obj = cls(**data)
        self.create_entity(obj)

    def update_entity_interactive(self, cls):
        pk = int(input("ID del registro a actualizar: "))
        obj = self.session.get(cls, pk)
        if not obj:
           print("❌ No encontrado.")
           return
        mapper = inspect(cls)
        for col in mapper.columns:
           if col.primary_key:
              continue
           current = getattr(obj, col.name)
           val = input(f"{col.name} actual='{current}'  nuevo:= ")
           if val != "":
              setattr(obj, col.name, self.cast_value(col, val))
        self.update_entity()

    from tabulate import tabulate

    def list_all_entities(self, model_class, page_size=200):
        columns = model_class.__table__.columns.keys()
        primary_key = list(model_class.__table__.primary_key.columns)[0].name
        order_column = getattr(model_class, primary_key)

        registros = self.session.query(model_class).order_by(order_column).all()

        if not registros:
            print("\033[93mNo hay registros disponibles.\033[0m")
            return

        total = len(registros)
        print(f"\n\033[96mTotal de registros: {total}\033[0m\n")

        for i in range(0, total, page_size):
            data = [[getattr(r, col) for col in columns] for r in registros[i:i + page_size]]
            tabla = tabulate(data, headers=columns, tablefmt="fancy_grid", stralign="center")
            print(tabla)

            if i + page_size < total:
                input("\n\033[93mPresione Enter para ver más registros...\033[0m")
            else:
                input("\n\033[92mFin de la lista. Presione Enter para volver al menú actual...\033[0m")